-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 30, 2021 at 08:18 AM
-- Server version: 10.5.12-MariaDB
-- PHP Version: 7.3.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id17824824_ranim_5th_year`
--

-- --------------------------------------------------------

--
-- Table structure for table `monitoring`
--

CREATE TABLE `monitoring` (
  `patient_id` int(11) NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `monitoring`
--

INSERT INTO `monitoring` (`patient_id`, `timestamp`) VALUES
(3, '2021-10-30 06:56:49'),
(1, '2021-10-30 08:15:34');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `patient_id` int(11) NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp(),
  `status` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '(Pending..)',
  `processed_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`patient_id`, `timestamp`, `status`, `processed_at`) VALUES
(1, '2021-10-27 11:10:48', 'Processed', NULL),
(2, '2021-10-28 11:10:48', 'Processed', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `passcode` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `medication_morning` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `medication_evening` longtext COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `passcode`, `first_name`, `last_name`, `medication_morning`, `medication_evening`) VALUES
('1', 'hla2DaF3', 'Rami', 'Agha', '- Propranolol 20 mg X1 (Tablet)\r\n- Norvasc 5 mg X1 (Tablet)', '- Propranolol 20 mg X1 (Tablet)\r\n- Norvasc 5 mg X1 (Tablet)\r\n- L-Thyroxin 50 μg X1 (Tablet)'),
('2', 'ldAOEE21', 'Sami', 'Al Sabbagh', '- Pravastatin 40 mg X1 (Tablet)\r\n- Mitformin (Immediate-release) 500 mg X1 (Tablet)', '- Pravastatin 40 mg X1 (Tablet)\r\n- Mitformin (Immediate-release) 500 mg X1 (Tablet)\r\n- Gabapentin 1800 mg X1 (Tablet) [with the evening meal]'),
('3', 'LL31Deao', 'Samah', 'Al Samman', NULL, '- L-Thyroxin 50 μg X1 (Tablet)');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
